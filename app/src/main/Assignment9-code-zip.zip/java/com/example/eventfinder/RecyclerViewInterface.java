package com.example.eventfinder;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
