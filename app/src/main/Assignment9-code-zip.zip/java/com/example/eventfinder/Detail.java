package com.example.eventfinder;

public class Detail {
}
