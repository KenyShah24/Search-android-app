package com.example.eventfinder;

public interface VolleyCallBack {
    void onSuccess();
}
